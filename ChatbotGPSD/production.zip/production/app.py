# app.py
from flask import Flask, render_template, request, jsonify
from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.document_loaders.mongodb import MongodbLoader
from dotenv import load_dotenv
import os

app = Flask(__name__)

# Load environment variables
load_dotenv()

# Initialize LLM
llm = ChatGoogleGenerativeAI(
    model="gemini-1.5-pro",
    temperature=0,
    max_tokens=None,
    timeout=None,
    max_retries=2,
)

# Initialize MongoDB loader
loader = MongodbLoader(
    connection_string="mongodb+srv://deshcode0:helloworld@loan0.1ydti.mongodb.net/?retryWrites=true&w=majority&appName=loan0",
    db_name="loan_database",
    collection_name="loan_system",
    field_names=[
        "_id", "customer_id", "first_name", "last_name", "date_of_birth",
        "address", "phone", "email", "national_id", "loan_id", "loan_type",
        "principal_amount", "interest_rate", "loan_term_months", "start_date",
        "end_date", "loan_status", "collaterals", "repayments",
        "payment_schedule", "loan_application", "assigned_employee", "branch"
    ]
)

# Load documents and create vector store
all_docs = loader.load()
text_splitter = RecursiveCharacterTextSplitter(chunk_size=50, chunk_overlap=20)
splits = text_splitter.split_documents(all_docs)
embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
vectorstore = FAISS.from_documents(documents=splits, embedding=embeddings)
retriever = vectorstore.as_retriever()

# Create prompt template
system_prompt = """

You are a loan management assistant chatbot. Based on the customer and loan data provided, respond to user queries effectively. Here's how you can structure your responses:

1. **Customer Information**:
    - Name: customer_name
    - Customer ID: customer_id
    - Date of Birth: dob
    - Address: address
    - Phone: phone
    - Email: email

2. **Loan Information**:
    - Loan ID: loan_id
    - Loan Type: loan_type
    - Amount: loan_amount
    - Interest Rate: interest_rate%
    - Loan Term: loan_term months
    - Start Date: loan_start_date
    - End Date: loan_end_date
    - Status: loan_status

3. **Collateral Details**:
    - Collateral Type: collateral_type
    - Description: collateral_description
    - Appraised Value: appraised_value
    - Date of Valuation: date_of_valuation

4. **Repayment History** (if available):
    - Repayment ID: repayment_id
    - Date: repayment_date
    - Amount Paid: amount_paid
    - Principal Paid: principal_paid
    - Interest Paid: interest_paid
    - Remaining Balance: remaining_balance

5. **Payment Schedule**:
    - Schedule ID: schedule_id
    - Due Date: due_date
    - Payment Due: payment_due
    - Status: status

6. **Employee Information**:
    - Assigned Employee: employee_name (position)
    - Email: employee_email
    - Phone: employee_phone

7. **Branch Information**:
    - Branch Name: branch_name
    - Address: branch_address
    - Phone: branch_phone

### Example Queries
- "What is the repayment history for Loan ID loan_id?"
- "Who is the assigned employee for Customer ID customer_id?"
- "Provide details about the collateral for Loan ID loan_id."
- "What is the loan status for Customer ID customer_id?"
- "Generate a repayment schedule for Loan ID loan_id."

### Notes
- Respond in a clear, concise manner.
- Ensure data consistency and accuracy based on the database records.
- If data is missing, inform the user politely and suggest next steps.

# Output data in message readable form

{context}
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("human", "{input}"),
])

# Create chains
question_answer_chain = create_stuff_documents_chain(llm, prompt)
rag_chain = create_retrieval_chain(retriever, question_answer_chain)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def query():
    user_query = request.json.get('query', '')
    if not user_query:
        return jsonify({'error': 'Query is required'}), 400
    
    try:
        response = rag_chain.invoke({"input": user_query})
        formatted_response = format_response(response['answer'])
        return jsonify({'response': formatted_response})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def format_response(response_text):
    import re
    formatted_text = re.sub(r"\*\*", "", response_text)
    formatted_text = formatted_text.replace("\\n", "\n")
    return formatted_text

if __name__ == '__main__':
    app.run(debug=True)